/*
Name: Rylan McAlsiter
Date: 8-10-19
*/

import java.awt.Graphics;
import java.util.Random;

public class Bank extends Sprite{

    public Bank(){
        super("bank.png");
        setY(300);
        setX(300);
    }
    
    @Override
    public void updateImage(Graphics graphics) {
        super.updateImage(graphics);
    }
} 